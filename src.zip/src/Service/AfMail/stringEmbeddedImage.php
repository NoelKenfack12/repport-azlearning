<?php
/**
* String based embedded image class
*/
namespace App\Service\AfMail;

require_once(dirname(__FILE__) . '/stringAttachment.php');

class stringEmbeddedImage extends stringAttachment
{
}
