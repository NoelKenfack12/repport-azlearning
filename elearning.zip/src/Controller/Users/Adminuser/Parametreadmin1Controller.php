<?php
/*(c) Noel Kenfack <noel.kenfack@yahoo.fr> Février 2015
*/
namespace App\Controller\Users\Adminuser;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use App\Entity\Users\Adminuser\Parametreadmin;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use App\Service\Servicetext\GeneralServicetext;
use Symfony\Component\HttpFoundation\Request;;
use App\Form\Users\Adminuser\ParametreadminType;

class Parametreadmin1Controller extends AbstractController
{
}