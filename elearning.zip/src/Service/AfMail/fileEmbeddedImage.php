<?php
/**
* File based embedded image class
*/
namespace App\Service\AfMail;

require_once(dirname(__FILE__) . '/fileAttachment.php');

class fileEmbeddedImage extends fileAttachment
{
}
